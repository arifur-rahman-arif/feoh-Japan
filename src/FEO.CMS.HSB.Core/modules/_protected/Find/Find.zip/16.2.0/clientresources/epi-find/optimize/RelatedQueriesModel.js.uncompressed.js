define("epi-find/optimize/RelatedQueriesModel", [
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",

    "dojo/Stateful",
    "dijit/Destroyable",

    "dojox/mvc/EditStoreRefController",
    "epi-saas-base/mvc/_CommitReturnMixin",
    "epi-saas-base/mvc/_EmptiableRefControllerMixin"
],
    function(declare, array, lang,
             all, when,
             Stateful, Destroyable,
             EditStoreRefController, _CommitReturnMixin, _EmptiableRefControllerMixin) {

        // module:
        //      epi-find/manage/RelatedQueriesModel

        return declare([Stateful, Destroyable], {
            // summary:
            //     Model for the Related Queries view.

            // store: dojo/store/JsonRest
            //      A store that is used for saving data
            store: null,

            // ctrl: dojox/mvc/EditStoreRefController
            //      A controller for binding
            ctrl: null,

            // searchText: String
            //      A search query
            searchText: null,
            _searchTextSetter: function(value) {
                if (value) {
                    this.set("gridQuery", {q: value + "*"});
                }
                else {
                    this.set("gridQuery", {});
                }
            },

            // gridQuery: Object
            //      Query for the grid
            gridQuery: null,

            postscript: function() {
                this.inherited(arguments);
                var BindingController = declare([EditStoreRefController, _CommitReturnMixin, _EmptiableRefControllerMixin]);
                this.ctrl = new BindingController({
                    store: this.store,
                    emptyModel: new Stateful({priority:1})
                });
                this.gridQuery = {};
            },

            moveUp: function(data) {
                // summary:
                //      Places specified suggestion above the previous suggestion in
                //      a sorted by priority list of suggestions that belongs to the same query.
                // data: Object
                //      A suggestion entity that is going to be moved up
                // returns: dojo/promise/Promise
                var suggestionId = this._findPreviousSuggestion(data);
                if (suggestionId === null) {
                    return null;
                }
                return this._swapSuggestions(data, suggestionId);
            },


            moveDown: function(data) {
                // summary:
                //      Places specified suggestion below the next suggestion in
                //      a sorted by priority list of suggestions that belongs to the same query.
                // data: Object
                //      A suggestion entity that is going to be moved down
                // returns: dojo/promise/Promise
                var suggestionId = this._findNextSuggestion(data);
                if (suggestionId === null) {
                    return null;
                }
                return this._swapSuggestions(data, suggestionId);
            },

            remove: function(id) {
                // summary:
                //      Removes a suggestion with specified ID
                return this.store.remove(id);
            },

            canMoveUp: function(data) {
                // summary:
                //      Verifies if a specified suggestion can be moved up in a sorted by priority
                //      list of suggestions that belongs to the same query
                // returns: Boolean
                return this._findPreviousSuggestion(data) !== null;
            },

            canMoveDown: function(data) {
                // summary:
                //      Verifies if a specified suggestion can be moved down in a sorted by priority
                //      list of suggestions that belongs to the same query
                // returns: Boolean

                return this._findNextSuggestion(data) !== null;
            },

            saveChanges: function() {
                // summary:
                //      Saves changes made in binding controller (ctrl).
                //  description:
                //      Before a new item is saved a check for existing suggestions is performed.
                //      If there are suggestions with the same query, the priority of the new item
                //      is set to the highest priority of existing suggestions plus one.
                //      Method also transforms multiple suggestions entered as a comma-separated list
                //      to a series of commits that create a separate entity for each suggestion.
                // returns: dojo/promise/Promise
                var self = this, query = this.ctrl.get("query");

                return when(this.store.query({query: query}), function(otherSuggestions) {
                    var commits, suggestions = self.ctrl.get("suggestion").split(","),
                        id = self.ctrl.get(self.store.idProperty),
                        // If a language is set on the store, we want to set a high base priority so
                        // suggestion comes before other suggestions from "all languages"
                        basePriority = self.store.language ? 10000 : 0;

                    if (otherSuggestions && otherSuggestions.length) {
                        basePriority = otherSuggestions[0].priority; // get the topmost suggestion priority
                    }
                    commits = array.map(suggestions, function (item, index) {
                        // keep ID only for the first suggestion and reset ID for others
                        // in order to perform add instead of put
                        if (index > 0) {
                            var model = lang.clone(self.ctrl.get("model"));
                            delete model[self.store.idProperty];
                            self.ctrl.set("model", model);
                        }
                        if (!id || index > 0) { // set priority for new items
                            self.ctrl.set("priority", basePriority + suggestions.length - index);
                        }

                        self.ctrl.set("suggestion", item);
                        return self.ctrl.commit();
                    });
                    return all(commits);
                });
            },

            reorderAll: function (data) {
                //  summary:
                //      Range all suggestions related to a specified item by priority
                //  data: Object
                //      A related query entity with other_suggestions property holding
                //      an array of other suggestions IDs related to the same query.
                var self = this;
                return all(
                    array.map(data.other_suggestions, function (id, index) {
                        return when(self.store.get(id), function (otherSuggestion) {
                            var newPriority = data.other_suggestions.length - index;
                            if (otherSuggestion.priority !== newPriority) {
                                otherSuggestion.priority = newPriority;
                                return self.store.put(otherSuggestion);
                            }
                        });
                    })
                );
            },

            _findPreviousSuggestion: function (data) {
                var previousSuggestion = null;
                if (data && data.other_suggestions) {
                    var currentItemIndex = array.indexOf(data.other_suggestions, data.id);
                    if (currentItemIndex-1 >= 0) {
                        previousSuggestion = data.other_suggestions[currentItemIndex-1];
                    }
                }
                return previousSuggestion;
            },

            _findNextSuggestion: function(data) {
                var nextSuggestion = null;
                if (data && data.other_suggestions) {
                    var currentItemIndex = array.indexOf(data.other_suggestions, data.id);
                    if (currentItemIndex > -1 && currentItemIndex+1 < data.other_suggestions.length) {
                        nextSuggestion = data.other_suggestions[currentItemIndex+1];
                    }
                }
                return nextSuggestion;
            },

            _swapSuggestions: function (data, suggestionId) {
                var self = this;
                return when(this.store.get(suggestionId), function (suggestion) {
                    if (data.priority === suggestion.priority) {
                        var currentIndex = array.indexOf(data.other_suggestions, data.id),
                            suggestionIndex = array.indexOf(data.other_suggestions, suggestion.id);
                        data.other_suggestions[currentIndex] = suggestion.id;
                        data.other_suggestions[suggestionIndex] = data.id;
                        return self.reorderAll(data);
                    }

                    self._swapPriority(data, suggestion);
                    return all([
                        self.store.put(data),
                        self.store.put(suggestion)
                    ]);
                });
            },

            _swapPriority: function(data, otherSuggestion) {
                var tmp = data.priority;
                data.priority = otherSuggestion.priority;
                otherSuggestion.priority = tmp;
                otherSuggestion.query = data.query;
                otherSuggestion.tags = lang.clone(data.tags);
            }

        });
    });
