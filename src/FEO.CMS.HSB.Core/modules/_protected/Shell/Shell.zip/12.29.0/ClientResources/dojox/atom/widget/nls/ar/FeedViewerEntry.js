//>>built
define("dojox/atom/widget/nls/ar/FeedViewerEntry",({deleteButton:"[حذف]"}));