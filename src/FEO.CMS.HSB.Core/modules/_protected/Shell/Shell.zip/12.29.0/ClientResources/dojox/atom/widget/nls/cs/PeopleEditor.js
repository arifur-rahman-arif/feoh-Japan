//>>built
define("dojox/atom/widget/nls/cs/PeopleEditor",({add:"Přidat",addAuthor:"Přidat autora",addContributor:"Přidat přispěvatele"}));